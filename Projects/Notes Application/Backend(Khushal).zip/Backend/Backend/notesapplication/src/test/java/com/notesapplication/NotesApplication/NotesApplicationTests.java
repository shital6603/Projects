package com.notesapplication.NotesApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotesApplicationTests {

	@Test
	void contextLoads() {
	}

}
